package entity;

import java.text.DecimalFormat;

public class Product {
	private int productID;
	private String productName;
	private String productType;
	private float price;

	public Product(String productName, String productType, float price) {
		this.productName = productName;
		this.productType = productType;
		this.price = price;
	}

	public Product(int productID, String productName, String productType, float price) {
		this.productID = productID;
		this.productName = productName;
		this.productType = productType;
		this.price = price;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	DecimalFormat dcf = new DecimalFormat("#,###");
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName=" + productName + ", productType=" + productType
				+ ", price=" + dcf.format(price) + "]";
	}

}

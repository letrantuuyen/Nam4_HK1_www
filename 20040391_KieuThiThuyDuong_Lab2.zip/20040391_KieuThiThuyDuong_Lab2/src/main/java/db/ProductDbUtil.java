package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import entity.Product;

public class ProductDbUtil {

	private DataSource dataSource;

	public ProductDbUtil(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<Product> getProducts() throws SQLException {
		List<Product> listProduct = new ArrayList<>();
		Connection conn = null;
		Statement stm = null;
		ResultSet rsSet = null;
		try {
			conn = dataSource.getConnection();
			String sql = "Select * from Products";

			stm = conn.createStatement();
			rsSet = stm.executeQuery(sql);

			while (rsSet.next()) {
				int id = rsSet.getInt("productID");
				String name = rsSet.getString("productName");
				String type = rsSet.getString("ProductType");
				float price = rsSet.getFloat("productPrice");
				Product product = new Product(id, name, type, price);

				listProduct.add(product);

			}
			return listProduct;
		} finally {
			// TODO: handle finally clause
			close(conn, stm, rsSet);
		}
	}
	
	public Product getProductById(String theProductID) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		Product theProduct = null;
		int id = Integer.parseInt(theProductID);
		try {
			myConn = dataSource.getConnection();

			String sql = "select * from Products where productID=?";

			myStmt = myConn.prepareStatement(sql);
			myStmt.setInt(1, id);

			myRs = myStmt.executeQuery();
			if (myRs.next()) {
				String productName = myRs.getString("productName");
				String productType = myRs.getString("productType");
				Float price = myRs.getFloat("productPrice");
				theProduct = new Product(productName, productType, price);
			} else {
				throw new Exception("Cound not find product id:" + theProductID);
			}
			return theProduct;
		} finally {
			// TODO: handle finally clause
			close(myConn, myStmt, myRs);
		}

	}

	public void addProduct(Product product) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {
			myConn = dataSource.getConnection();
			String sql = "insert into Products " + "(ProductName,ProductType,ProductPrice)" + "values (?,?,?)";
			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, product.getProductName());
			myStmt.setString(2, product.getProductType());
			myStmt.setFloat(3, product.getPrice());

			myStmt.execute();

		} finally {
			// TODO: handle finally clause
			close(myConn, myStmt, null);
		}

	}

	public void deleteProduct(String theProductId) throws Exception {

		Connection myConnection = null;
		PreparedStatement myStmt = null;

		try {
			int productId = Integer.parseInt(theProductId);

			myConnection = dataSource.getConnection();

			String sql = "delete from Products where productID=?";

			myStmt = myConnection.prepareStatement(sql);

			myStmt.setInt(1, productId);

			myStmt.execute();
		} finally {
			// TODO: handle finally clause
			close(myConnection, myStmt, null);
		}

	}

	public void updateProduct(Product theProduct) throws Exception {

		Connection myConn = null;
		PreparedStatement myStmt = null;

		try {

			myConn = dataSource.getConnection();

			String sql = "update Products " + "set productName=?, productType=?, productPrice=? " + "where productID=?";
			myStmt = myConn.prepareStatement(sql);

			myStmt.setString(1, theProduct.getProductName());
			myStmt.setString(2, theProduct.getProductType());
			myStmt.setFloat(3, theProduct.getPrice());
			myStmt.setInt(4, theProduct.getProductID());

			myStmt.execute();

		} finally {
			// TODO: handle finally clause
			close(myConn, myStmt, null);
		}

	}

	private void close(Connection conn, Statement stm, ResultSet rsSet) {
		// TODO Auto-generated method stub
		try {
			if (conn != null) {
				conn.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (rsSet != null) {
				rsSet.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
